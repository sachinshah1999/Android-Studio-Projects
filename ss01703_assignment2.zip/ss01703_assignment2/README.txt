Name: Sachin Pratap Shah
Email: ss01703@surrey.ac.uk
App Name: ss01703_assignment2

Special Instructions:

- Open google maps before running the app from android studio
- This to ensure the app can obtain the last known location

- I wasn't sure on how to give you access to my firebase. So I did the following: https://goo.gl/2V8jSJ (I assure you this isn't a virus link lol)
- I also did the following: https://goo.gl/BDfvtz
- Here is a screenshot of my database: https://goo.gl/6DZsfk
	- Each marker has a type e.g. fitness or pharmacy.
	- Each type has a numbered table (staring from 1) which represent the marker's "ID"
	- Each marker ID table, has the POI name, type and location. 

Brief Description:

- Navigate using the navigation drawer or 

Activity 1) Current Location 

- Give the user's current location, as a marker on the map
- Users can also search for locations via the search box
- Clicking on the floating button changes the map's camera to the user's current location

Activity 2) Points of Interest activity   

- Does everything in activity 1
- Shows points of interest markers on the map. 
- Clicking on the markers info window, will display a path from the user's current location, to the POI marker location. (sometimes it will say direction not found, just click on the info window again, untill the path is shown on the map)
- Users will get notified by a toast message and a notification message, when they are close to a point of interest.

Activity 3) Street View actvity

- Users can search for locations in the search box and the street view for that location will appear. 



